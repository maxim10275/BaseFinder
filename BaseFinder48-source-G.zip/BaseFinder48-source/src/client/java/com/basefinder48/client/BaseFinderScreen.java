package com.basefinder48.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class BaseFinderScreen extends Screen {
    public BaseFinderScreen() {
        super(Component.literal("BaseFinder #48"));
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int top = this.height / 4;

        this.addRenderableWidget(Button.builder(Component.literal("−"), button -> {
            BaseFinderSettings.changeHeight(-1);
            refreshHeightLabel();
        }).bounds(center - 105, top + 34, 40, 20).build());

        this.addRenderableWidget(Button.builder(heightLabel(), button -> {
            // Value is adjusted with the +/- buttons.
        }).bounds(center - 60, top + 34, 120, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("+"), button -> {
            BaseFinderSettings.changeHeight(1);
            refreshHeightLabel();
        }).bounds(center + 65, top + 34, 40, 20).build());

        this.addRenderableWidget(Button.builder(waterLabel(), button -> {
            BaseFinderSettings.avoidWater = !BaseFinderSettings.avoidWater;
            button.setMessage(waterLabel());
        }).bounds(center - 100, top + 66, 200, 20).build());

        this.addRenderableWidget(Button.builder(telegramLabel(), button -> {
            BaseFinderSettings.telegramNotifications = !BaseFinderSettings.telegramNotifications;
            button.setMessage(telegramLabel());
        }).bounds(center - 100, top + 94, 200, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Закрыть"), button -> this.onClose())
                .bounds(center - 100, top + 132, 200, 20).build());
    }

    private Component heightLabel() {
        return Component.literal("Высота: " + BaseFinderSettings.searchHeight);
    }

    private Component waterLabel() {
        return Component.literal("Обход воды: " + (BaseFinderSettings.avoidWater ? "ВКЛ" : "ВЫКЛ"));
    }

    private Component telegramLabel() {
        return Component.literal("Telegram-уведомления: " +
                (BaseFinderSettings.telegramNotifications ? "ВКЛ" : "ВЫКЛ"));
    }

    private void refreshHeightLabel() {
        this.clearWidgets();
        this.init();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 4, 0xFFFFFF);
        graphics.drawCenteredString(this.font,
                "Прототип меню — настройки пока локальные",
                this.width / 2, this.height / 4 + 18, 0xAAAAAA);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
