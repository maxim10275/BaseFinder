package com.basefinder48.client;

/**
 * In-memory preferences for the first BaseFinder #48 prototype.
 * Persistence and gameplay automation will be added in later iterations.
 */
public final class BaseFinderSettings {
    private BaseFinderSettings() {}

    public static int searchHeight = 64;
    public static boolean avoidWater = true;
    public static boolean telegramNotifications = false;

    public static void changeHeight(int delta) {
        searchHeight = Math.max(-64, Math.min(320, searchHeight + delta));
    }
}
