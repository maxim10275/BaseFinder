package com.basefinder48.client;

import com.basefinder48.BaseFinder48;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class BaseFinder48Client implements ClientModInitializer {
    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.basefinder48.open_menu",
                GLFW.GLFW_KEY_G,
                "category.basefinder48"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new BaseFinderScreen());
                }
            }
        });

        BaseFinder48.LOGGER.info("BaseFinder #48 client initialized. Press Right Shift to open settings.");
    }
}
