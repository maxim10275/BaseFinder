# BaseFinder #48

Prototype client mod for Minecraft Java 1.21.11 + Fabric.

## Included
- Right Shift opens the settings screen.
- Search-height value can be adjusted from -64 to 320.
- Water-avoidance and Telegram-notification preferences can be toggled.

## Important
This is a source project, not a compiled JAR. The current settings are in-memory only and reset when Minecraft restarts. No base-finding, private-region bypass, hidden-container detection, or automated server movement is implemented.

## Build
Use Java 21 and run:

```bash
./gradlew build
```

The remapped mod JAR should appear in `build/libs/`.


Открытие меню: клавиша G (можно изменить в Настройки → Управление → Назначение клавиш).
